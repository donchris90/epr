import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";

/**
 * Primary navigation is organized around the project lifecycle
 * (SRS Section 7.1), not around departments:
 *   Home -> Business Development -> Tenders -> Projects -> Company -> Reports & AI -> Admin
 *
 * TODO: as each module's frontend lands, add its route here and its own
 * sub-navigation under src/modules/<code>/.
 */
export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        {/* <Route path="/business-development/*" element={<BDCModule />} /> */}
        {/* <Route path="/tenders/*" element={<TBMModule />} /> */}
        {/* <Route path="/projects/*" element={<ProjectsModule />} /> */}
        {/* <Route path="/company/*" element={<CompanyModule />} /> */}
        {/* <Route path="/reports/*" element={<ReportsAndAIModule />} /> */}
        {/* <Route path="/admin/*" element={<AdminModule />} /> */}
      </Routes>
    </BrowserRouter>
  );
}
