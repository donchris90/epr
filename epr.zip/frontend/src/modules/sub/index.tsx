/**
 * Module: Subcontractor Management (Code: sub)
 * TODO: implement page-level components and routes for this module,
 * per SRS Section 4 (functional requirements) and Section 7 (UI/UX flows).
 */
export default function SUBModule() {
  return <div>Subcontractor Management — coming soon</div>;
}
