/**
 * Module: Vendor Portal (Code: vnp)
 * TODO: implement page-level components and routes for this module,
 * per SRS Section 4 (functional requirements) and Section 7 (UI/UX flows).
 */
export default function VNPModule() {
  return <div>Vendor Portal — coming soon</div>;
}
