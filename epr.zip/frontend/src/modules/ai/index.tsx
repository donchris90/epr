/**
 * Module: AI Construction Assistant (Code: ai)
 * TODO: implement page-level components and routes for this module,
 * per SRS Section 4 (functional requirements) and Section 7 (UI/UX flows).
 */
export default function AIModule() {
  return <div>AI Construction Assistant — coming soon</div>;
}
