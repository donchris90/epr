/**
 * Module: Financial Management (Code: fin)
 * TODO: implement page-level components and routes for this module,
 * per SRS Section 4 (functional requirements) and Section 7 (UI/UX flows).
 */
export default function FINModule() {
  return <div>Financial Management — coming soon</div>;
}
