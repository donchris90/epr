import axios from "axios";

export const apiClient = axios.create({
  baseURL: "/v1",
  headers: { "Content-Type": "application/json" },
});

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("access_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// TODO: response interceptor to auto-refresh the access token on 401
// using the refresh token, per SRS Section 6.2.
