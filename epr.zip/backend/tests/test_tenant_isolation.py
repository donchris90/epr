"""
Mandatory tenant-isolation test suite (SRS Section 12.2):

    "An automated test suite must attempt, for every tenant-scoped table,
    to read/write another tenant's row using a valid token for a different
    tenant, and must assert failure in 100% of cases. This suite runs on
    every CI build, not only periodically."

This file is intentionally the first test module in the repo. As each
module's models land, add a case here that:
  1. Creates a row owned by tenant A.
  2. Authenticates as a user belonging to tenant B.
  3. Asserts the row is NOT visible/readable/writable by tenant B, at
     both the API layer and (ideally) via a direct RLS-bypass attempt.

TODO: parametrize this over every tenant-scoped table as models are
implemented, per module.
"""
import pytest


@pytest.mark.skip(reason="Scaffolding placeholder — implement once Tenant/User/Project models are seeded")
def test_cross_tenant_read_is_blocked(client, db):
    """A user authenticated for tenant A must never be able to read a
    record belonging to tenant B, even via a direct primary-key lookup."""
    raise NotImplementedError


@pytest.mark.skip(reason="Scaffolding placeholder")
def test_cross_tenant_write_is_blocked(client, db):
    """A user authenticated for tenant A must never be able to write to
    a record belonging to tenant B."""
    raise NotImplementedError


@pytest.mark.skip(reason="Scaffolding placeholder")
def test_missing_tenant_filter_still_isolated(client, db):
    """Even a query missing an explicit WHERE tenant_id=... clause must
    not return another tenant's rows — this is what RLS guarantees at
    the database layer (SRS Section 3.4)."""
    raise NotImplementedError
