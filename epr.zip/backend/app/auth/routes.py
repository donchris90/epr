"""
Authentication endpoints (SRS Section 6.2).

    POST /v1/auth/login    email/password (or SSO token) -> access + refresh token
    POST /v1/auth/refresh  refresh token -> new access token
    POST /v1/auth/logout   revokes the refresh token

Access tokens are JWTs carrying tenant_id, user_id, role_id, and
permissions claims, verified on every request (see middleware/tenant_context.py)
and used to set the RLS session variable.

External portal users (Client Portal, Vendor Portal) authenticate through
this same endpoint family but receive tokens scoped to a restricted
permission set (SRS Section 8).
"""
from flask import Blueprint, jsonify, request
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    jwt_required,
    get_jwt_identity,
    get_jwt,
)

from app.auth.jwt_utils import authenticate_user, revoke_refresh_token

bp = Blueprint("auth", __name__, url_prefix="/v1/auth")


@bp.post("/login")
def login():
    data = request.get_json(force=True) or {}
    email = data.get("email")
    password = data.get("password")

    user = authenticate_user(email, password)
    if not user:
        return jsonify({"type": "about:blank", "title": "Invalid credentials", "status": 401}), 401

    claims = {
        "tenant_id": str(user.tenant_id),
        "user_id": str(user.id),
        "role_id": str(user.role_id) if user.role_id else None,
        "permissions": [],  # TODO: resolve from user.role.permission_set
    }

    access_token = create_access_token(identity=str(user.id), additional_claims=claims)
    refresh_token = create_refresh_token(identity=str(user.id), additional_claims=claims)

    return jsonify({"access_token": access_token, "refresh_token": refresh_token})


@bp.post("/refresh")
@jwt_required(refresh=True)
def refresh():
    identity = get_jwt_identity()
    claims = get_jwt()
    new_claims = {
        "tenant_id": claims.get("tenant_id"),
        "user_id": claims.get("user_id"),
        "role_id": claims.get("role_id"),
        "permissions": claims.get("permissions", []),
    }
    access_token = create_access_token(identity=identity, additional_claims=new_claims)
    return jsonify({"access_token": access_token})


@bp.post("/logout")
@jwt_required(refresh=True)
def logout():
    jti = get_jwt()["jti"]
    revoke_refresh_token(jti)
    return jsonify({"status": "logged_out"})
