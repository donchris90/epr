"""
Authentication helpers: password verification and refresh-token revocation.
Passwords are hashed with Argon2id (SRS Section 10.4) — no plaintext or
reversibly-encrypted password storage.
"""
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

from app.models.core import User

_hasher = PasswordHasher()


def hash_password(plain_password: str) -> str:
    return _hasher.hash(plain_password)


def authenticate_user(email: str, password: str):
    if not email or not password:
        return None

    user = User.query.filter_by(email=email, status="active").first()
    if not user:
        return None

    try:
        _hasher.verify(user.password_hash, password)
    except VerifyMismatchError:
        return None

    return user


# TODO: back this with a Redis-backed denylist of revoked refresh-token JTIs,
# checked in a JWTManager.token_in_blocklist_loader callback.
_REVOKED_JTIS = set()


def revoke_refresh_token(jti: str) -> None:
    _REVOKED_JTIS.add(jti)


def is_token_revoked(jti: str) -> bool:
    return jti in _REVOKED_JTIS
