"""
Module: Executive Dashboard
Marshmallow-style request & response schemas for the exd module.
"""
# TODO: define serialization schemas for Executive Dashboard
