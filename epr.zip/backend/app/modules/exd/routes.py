"""
Module: Executive Dashboard
Flask Blueprint exposing the REST API surface for the exd module.
Base path: /v1/exd
"""
from flask import Blueprint, jsonify

bp = Blueprint("exd", __name__, url_prefix="/v1/exd")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "exd", "name": "Executive Dashboard", "status": "ok"})

# TODO: implement functional requirements for Executive Dashboard per SRS Section 4
