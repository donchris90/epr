"""
Module: Subcontractor Management
Marshmallow-style request & response schemas for the sub module.
"""
# TODO: define serialization schemas for Subcontractor Management
