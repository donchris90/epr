"""
Module: Subcontractor Management
Flask Blueprint exposing the REST API surface for the sub module.
Base path: /v1/sub
"""
from flask import Blueprint, jsonify

bp = Blueprint("sub", __name__, url_prefix="/v1/sub")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "sub", "name": "Subcontractor Management", "status": "ok"})

# TODO: implement functional requirements for Subcontractor Management per SRS Section 4
