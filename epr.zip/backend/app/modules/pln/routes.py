"""
Module: Project Planning
Flask Blueprint exposing the REST API surface for the pln module.
Base path: /v1/pln
"""
from flask import Blueprint, jsonify

bp = Blueprint("pln", __name__, url_prefix="/v1/pln")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "pln", "name": "Project Planning", "status": "ok"})

# TODO: implement functional requirements for Project Planning per SRS Section 4
