"""
Module: Project Planning
Marshmallow-style request & response schemas for the pln module.
"""
# TODO: define serialization schemas for Project Planning
