"""
Module: Survey & Engineering
Marshmallow-style request & response schemas for the svy module.
"""
# TODO: define serialization schemas for Survey & Engineering
