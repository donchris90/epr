"""
Module: Fuel Management
Marshmallow-style request & response schemas for the fuel module.
"""
# TODO: define serialization schemas for Fuel Management
