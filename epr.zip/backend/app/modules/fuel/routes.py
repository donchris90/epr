"""
Module: Fuel Management
Flask Blueprint exposing the REST API surface for the fuel module.
Base path: /v1/fuel
"""
from flask import Blueprint, jsonify

bp = Blueprint("fuel", __name__, url_prefix="/v1/fuel")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "fuel", "name": "Fuel Management", "status": "ok"})

# TODO: implement functional requirements for Fuel Management per SRS Section 4
