"""
Module: Equipment & Fleet Management
Flask Blueprint exposing the REST API surface for the eqp module.
Base path: /v1/eqp
"""
from flask import Blueprint, jsonify

bp = Blueprint("eqp", __name__, url_prefix="/v1/eqp")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "eqp", "name": "Equipment & Fleet Management", "status": "ok"})

# TODO: implement functional requirements for Equipment & Fleet Management per SRS Section 4
