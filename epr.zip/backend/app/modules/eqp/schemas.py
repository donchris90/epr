"""
Module: Equipment & Fleet Management
Marshmallow-style request & response schemas for the eqp module.
"""
# TODO: define serialization schemas for Equipment & Fleet Management
