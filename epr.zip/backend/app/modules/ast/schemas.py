"""
Module: Asset Management
Marshmallow-style request & response schemas for the ast module.
"""
# TODO: define serialization schemas for Asset Management
