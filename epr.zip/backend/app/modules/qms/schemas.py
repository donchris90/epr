"""
Module: Quality Management QMS
Marshmallow-style request & response schemas for the qms module.
"""
# TODO: define serialization schemas for Quality Management QMS
