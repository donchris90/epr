"""
Module: AI Construction Assistant
Marshmallow-style request & response schemas for the ai module.
"""
# TODO: define serialization schemas for AI Construction Assistant
