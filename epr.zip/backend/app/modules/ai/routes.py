"""
Module: AI Construction Assistant
Flask Blueprint exposing the REST API surface for the ai module.
Base path: /v1/ai
"""
from flask import Blueprint, jsonify

bp = Blueprint("ai", __name__, url_prefix="/v1/ai")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "ai", "name": "AI Construction Assistant", "status": "ok"})

# TODO: implement functional requirements for AI Construction Assistant per SRS Section 4
