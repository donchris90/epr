"""
Module: Mobile Field App Sync API
Marshmallow-style request & response schemas for the mfa module.
"""
# TODO: define serialization schemas for Mobile Field App Sync API
