"""
Module: Contract Management
Marshmallow-style request & response schemas for the ctm module.
"""
# TODO: define serialization schemas for Contract Management
