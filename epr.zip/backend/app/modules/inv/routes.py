"""
Module: Inventory & Warehouse
Flask Blueprint exposing the REST API surface for the inv module.
Base path: /v1/inv
"""
from flask import Blueprint, jsonify

bp = Blueprint("inv", __name__, url_prefix="/v1/inv")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "inv", "name": "Inventory & Warehouse", "status": "ok"})

# TODO: implement functional requirements for Inventory & Warehouse per SRS Section 4
