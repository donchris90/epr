"""
Module: Inventory & Warehouse
Marshmallow-style request & response schemas for the inv module.
"""
# TODO: define serialization schemas for Inventory & Warehouse
