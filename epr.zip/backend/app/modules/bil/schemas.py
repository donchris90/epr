"""
Module: Client Billing
Marshmallow-style request & response schemas for the bil module.
"""
# TODO: define serialization schemas for Client Billing
