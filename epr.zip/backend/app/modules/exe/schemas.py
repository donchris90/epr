"""
Module: Project Execution
Marshmallow-style request & response schemas for the exe module.
"""
# TODO: define serialization schemas for Project Execution
