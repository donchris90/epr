"""
Module: Procurement
Marshmallow-style request & response schemas for the prc module.
"""
# TODO: define serialization schemas for Procurement
