"""
Module: Procurement
Flask Blueprint exposing the REST API surface for the prc module.
Base path: /v1/prc
"""
from flask import Blueprint, jsonify

bp = Blueprint("prc", __name__, url_prefix="/v1/prc")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "prc", "name": "Procurement", "status": "ok"})

# TODO: implement functional requirements for Procurement per SRS Section 4
