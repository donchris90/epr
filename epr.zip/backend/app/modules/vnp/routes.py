"""
Module: Vendor Portal
Flask Blueprint exposing the REST API surface for the vnp module.
Base path: /v1/vnp
"""
from flask import Blueprint, jsonify

bp = Blueprint("vnp", __name__, url_prefix="/v1/vnp")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "vnp", "name": "Vendor Portal", "status": "ok"})

# TODO: implement functional requirements for Vendor Portal per SRS Section 4
