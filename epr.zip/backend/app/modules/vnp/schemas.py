"""
Module: Vendor Portal
Marshmallow-style request & response schemas for the vnp module.
"""
# TODO: define serialization schemas for Vendor Portal
