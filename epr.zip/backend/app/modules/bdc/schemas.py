"""
Module: Business Development & CRM
Marshmallow-style request & response schemas for the bdc module.
"""
# TODO: define serialization schemas for Business Development & CRM
