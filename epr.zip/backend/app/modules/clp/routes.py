"""
Module: Client Portal
Flask Blueprint exposing the REST API surface for the clp module.
Base path: /v1/clp
"""
from flask import Blueprint, jsonify

bp = Blueprint("clp", __name__, url_prefix="/v1/clp")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "clp", "name": "Client Portal", "status": "ok"})

# TODO: implement functional requirements for Client Portal per SRS Section 4
