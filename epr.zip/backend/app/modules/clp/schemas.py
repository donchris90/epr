"""
Module: Client Portal
Marshmallow-style request & response schemas for the clp module.
"""
# TODO: define serialization schemas for Client Portal
