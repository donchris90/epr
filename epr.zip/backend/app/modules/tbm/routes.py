"""
Module: Tender & Bid Management
Flask Blueprint exposing the REST API surface for the tbm module.
Base path: /v1/tbm
"""
from flask import Blueprint, jsonify

bp = Blueprint("tbm", __name__, url_prefix="/v1/tbm")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "tbm", "name": "Tender & Bid Management", "status": "ok"})

# TODO: implement functional requirements for Tender & Bid Management per SRS Section 4
