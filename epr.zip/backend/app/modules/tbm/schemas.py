"""
Module: Tender & Bid Management
Marshmallow-style request & response schemas for the tbm module.
"""
# TODO: define serialization schemas for Tender & Bid Management
