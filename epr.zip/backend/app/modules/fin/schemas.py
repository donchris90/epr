"""
Module: Financial Management
Marshmallow-style request & response schemas for the fin module.
"""
# TODO: define serialization schemas for Financial Management
