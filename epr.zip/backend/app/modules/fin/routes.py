"""
Module: Financial Management
Flask Blueprint exposing the REST API surface for the fin module.
Base path: /v1/fin
"""
from flask import Blueprint, jsonify

bp = Blueprint("fin", __name__, url_prefix="/v1/fin")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "fin", "name": "Financial Management", "status": "ok"})

# TODO: implement functional requirements for Financial Management per SRS Section 4
