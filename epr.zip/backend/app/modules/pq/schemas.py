"""
Module: Plant & Quarry Management
Marshmallow-style request & response schemas for the pq module.
"""
# TODO: define serialization schemas for Plant & Quarry Management
