"""
Module: Plant & Quarry Management
Code: pq
SQLAlchemy models for this bounded context.
Every tenant-scoped table must inherit TenantMixin + AuditMixin (see app/models/base.py)
and have a matching RLS policy created in an Alembic migration.
"""
from app.extensions import db
from app.models.base import TenantMixin, AuditMixin, UUIDPrimaryKeyMixin

# TODO: define models for Plant & Quarry Management (Module pq)
# Example skeleton:
#
# class ExampleEntity(db.Model, UUIDPrimaryKeyMixin, TenantMixin, AuditMixin):
#     __tablename__ = "pq_example_entity"
#     name = db.Column(db.String(255), nullable=False)
