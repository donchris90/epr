"""
Module: Plant & Quarry Management
Flask Blueprint exposing the REST API surface for the pq module.
Base path: /v1/pq
"""
from flask import Blueprint, jsonify

bp = Blueprint("pq", __name__, url_prefix="/v1/pq")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "pq", "name": "Plant & Quarry Management", "status": "ok"})

# TODO: implement functional requirements for Plant & Quarry Management per SRS Section 4
