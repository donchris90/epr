"""
Module: Health, Safety & Environment
Marshmallow-style request & response schemas for the hse module.
"""
# TODO: define serialization schemas for Health, Safety & Environment
