"""
Module: Workforce Management
Flask Blueprint exposing the REST API surface for the wfm module.
Base path: /v1/wfm
"""
from flask import Blueprint, jsonify

bp = Blueprint("wfm", __name__, url_prefix="/v1/wfm")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "wfm", "name": "Workforce Management", "status": "ok"})

# TODO: implement functional requirements for Workforce Management per SRS Section 4
