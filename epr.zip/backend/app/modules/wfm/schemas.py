"""
Module: Workforce Management
Marshmallow-style request & response schemas for the wfm module.
"""
# TODO: define serialization schemas for Workforce Management
