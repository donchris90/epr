"""
Module: Workforce Management
Code: wfm
SQLAlchemy models for this bounded context.
Every tenant-scoped table must inherit TenantMixin + AuditMixin (see app/models/base.py)
and have a matching RLS policy created in an Alembic migration.
"""
from app.extensions import db
from app.models.base import TenantMixin, AuditMixin, UUIDPrimaryKeyMixin

# TODO: define models for Workforce Management (Module wfm)
# Example skeleton:
#
# class ExampleEntity(db.Model, UUIDPrimaryKeyMixin, TenantMixin, AuditMixin):
#     __tablename__ = "wfm_example_entity"
#     name = db.Column(db.String(255), nullable=False)
