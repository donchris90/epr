"""
Module: Estimating & Cost Engineering
Flask Blueprint exposing the REST API surface for the est module.
Base path: /v1/est
"""
from flask import Blueprint, jsonify

bp = Blueprint("est", __name__, url_prefix="/v1/est")


@bp.get("/health")
def health():
    """Lightweight per-module health check, useful during scaffolding."""
    return jsonify({"module": "est", "name": "Estimating & Cost Engineering", "status": "ok"})

# TODO: implement functional requirements for Estimating & Cost Engineering per SRS Section 4
