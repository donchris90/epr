"""
Tenant Context Middleware (SRS Section 3.4 / 5.5).

Resolves tenant_id from the verified JWT and sets it as a Postgres
session variable (`app.tenant_id`) at the start of every request, so
Row-Level Security policies on every tenant-scoped table can enforce
isolation at the database layer — a bug in application-layer filtering
cannot leak cross-tenant data, because the database itself refuses to
return rows outside the current tenant.

This is the single most safety-critical file in the platform. Every
tenant-scoped table's RLS policy depends on this variable being set
correctly, and reset between requests.
"""
from flask import g, request
from flask_jwt_extended import verify_jwt_in_request, get_jwt
from sqlalchemy import text


PUBLIC_PATHS = {
    "/v1/health",
    "/v1/auth/login",
    "/v1/auth/refresh",
}


def register_tenant_context(app, db):
    @app.before_request
    def set_tenant_context():
        if request.path in PUBLIC_PATHS or request.path.endswith("/health"):
            return

        # Verify JWT and extract tenant_id claim (optional=True lets
        # individual routes decide whether auth is required).
        verify_jwt_in_request(optional=True)
        claims = get_jwt() or {}
        tenant_id = claims.get("tenant_id")
        g.tenant_id = tenant_id
        g.user_id = claims.get("user_id")
        g.role_id = claims.get("role_id")
        g.permissions = claims.get("permissions", [])

        if tenant_id:
            db.session.execute(
                text("SET LOCAL app.tenant_id = :tenant_id"),
                {"tenant_id": str(tenant_id)},
            )

    @app.teardown_appcontext
    def clear_tenant_context(exception=None):
        # SET LOCAL is transaction-scoped and clears automatically on
        # commit/rollback, but we drop the Flask `g` reference too.
        g.pop("tenant_id", None)
        g.pop("user_id", None)
        g.pop("role_id", None)
        g.pop("permissions", None)
