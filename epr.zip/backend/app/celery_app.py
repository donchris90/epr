"""
Celery worker entrypoint. Run with:
    celery -A app.celery_app.celery worker --loglevel=info

Handles background jobs: report generation, AI Assistant calls,
notification fan-out, scheduled reorder/expiry checks (SRS Section 3.1/13.2).
"""
from app import create_app
from app.extensions import celery


def init_celery(app):
    celery.conf.update(
        broker_url=app.config["CELERY_BROKER_URL"],
        result_backend=app.config["CELERY_RESULT_BACKEND"],
    )

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask
    return celery


flask_app = create_app()
celery = init_celery(flask_app)

# Import task modules here as they're implemented, e.g.:
# from app.modules.ai import tasks as ai_tasks  # noqa
