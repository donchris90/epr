"""
SiteForge backend application factory.

Modular monolith: a single deployable Flask app internally organized into
25 bounded-context modules (see app/modules/*), each owning its own tables
and exposing a Python service interface (SRS Section 3.3).
"""
from flask import Flask

from app.config import get_config
from app.extensions import db, migrate, jwt, cors, celery, cache
from app.middleware.tenant_context import register_tenant_context


# Every module's blueprint, in the order listed in SRS Section 4.
MODULE_BLUEPRINTS = [
    ("app.modules.bdc.routes", "bp"),
    ("app.modules.tbm.routes", "bp"),
    ("app.modules.est.routes", "bp"),
    ("app.modules.ctm.routes", "bp"),
    ("app.modules.pln.routes", "bp"),
    ("app.modules.exe.routes", "bp"),
    ("app.modules.prc.routes", "bp"),
    ("app.modules.inv.routes", "bp"),
    ("app.modules.eqp.routes", "bp"),
    ("app.modules.fuel.routes", "bp"),
    ("app.modules.wfm.routes", "bp"),
    ("app.modules.sub.routes", "bp"),
    ("app.modules.qms.routes", "bp"),
    ("app.modules.hse.routes", "bp"),
    ("app.modules.svy.routes", "bp"),
    ("app.modules.pq.routes", "bp"),
    ("app.modules.fin.routes", "bp"),
    ("app.modules.bil.routes", "bp"),
    ("app.modules.pc.routes", "bp"),
    ("app.modules.ast.routes", "bp"),
    ("app.modules.exd.routes", "bp"),
    ("app.modules.clp.routes", "bp"),
    ("app.modules.vnp.routes", "bp"),
    ("app.modules.mfa.routes", "bp"),
    ("app.modules.ai.routes", "bp"),
]


def create_app(config_name: str = None) -> Flask:
    app = Flask(__name__)
    app.config.from_object(get_config(config_name))

    # --- extensions ---
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    cors.init_app(app, supports_credentials=True)
    cache.init_app(app)

    # --- tenant-context middleware (SRS Section 3.4 / 5.5) ---
    register_tenant_context(app, db)

    # --- auth blueprint ---
    from app.auth.routes import bp as auth_bp
    app.register_blueprint(auth_bp)

    # --- module blueprints ---
    import importlib

    for module_path, attr in MODULE_BLUEPRINTS:
        module = importlib.import_module(module_path)
        app.register_blueprint(getattr(module, attr))

    # --- error handlers (RFC 7807 Problem Details, SRS Section 6.1) ---
    from app.utils.errors import register_error_handlers
    register_error_handlers(app)

    @app.get("/v1/health")
    def platform_health():
        return {"status": "ok", "service": "siteforge-api"}

    return app
