"""
Shared Flask extension instances, initialized in the app factory
(app/__init__.py) to avoid circular imports across the 25 modules.
"""
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_caching import Cache
from celery import Celery

db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()
cors = CORS()
cache = Cache()

# Celery is configured fully once the app factory has bound its config;
# see app/celery_app.py for the bound instance used by worker processes.
celery = Celery(__name__)
