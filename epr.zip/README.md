# SiteForge

**Construction Management Platform** — a multi-tenant, cloud-based SaaS
platform for civil engineering and building contractors, purpose-built
for African markets, spanning the full construction project lifecycle:
tender → estimate → contract → planning → execution → procurement →
materials → equipment → labor → quality → safety → finance → billing →
closeout → asset management.

Full specification: [`docs/SRS.md`](docs/SRS.md) (25 functional modules,
database schema, API contracts, UI/UX flows, permission matrix,
non-functional requirements, roadmap, testing requirements, and
deployment architecture).

## Repository layout

```
SiteForge/
├── backend/          Flask 3 modular monolith (Python 3.13, SQLAlchemy, PostgreSQL 16 + RLS)
│   └── app/modules/  One folder per bounded context — all 25 SRS modules
├── frontend/          React + TypeScript (Vite) web app
│   └── src/modules/  Mirrors the backend's 25 modules
├── mobile/            Flutter offline-first Mobile Field App (Module 24)
├── docs/              SRS and supporting docs
└── docker-compose.yml Local dev topology: Postgres, Redis, MinIO, API, worker, web
```

## Architecture at a glance

- **Modular monolith**: one deployable Flask app, internally organized
  into 25 bounded contexts that map 1:1 to the SRS modules. Each module
  owns its own tables and exposes a service interface — other modules
  call that interface rather than reaching into another module's tables
  directly (SRS §3.3).
- **Multi-tenant isolation via Postgres Row-Level Security**: every
  tenant-scoped table carries `tenant_id`, and a request-scoped
  middleware sets `app.tenant_id` so RLS policies enforce isolation at
  the database layer — not only in application code (SRS §3.4/5.5).
- **Offline-first mobile**: the Flutter app mirrors relevant server data
  into a local SQLite (Drift) store, queues writes locally, and syncs in
  batches with server-side conflict tracking (SRS §3.5).
- **AI Construction Assistant**: a Celery-backed service that retrieves
  tenant-scoped context and calls the Anthropic API with tool-calling
  for structured lookups and document extraction (SRS §3.6).

## Getting started (local development)

### 1. Backend

```bash
cd backend
cp .env.example .env
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
flask db upgrade          # once migrations exist
flask run                 # or: gunicorn -w 4 -b 0.0.0.0:8000 wsgi:app
```

### 2. Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

### 3. Full stack via Docker Compose

```bash
docker compose up --build
```

Brings up Postgres, Redis, MinIO (S3-compatible storage), the Flask API,
a Celery worker, and the Vite dev server.

### 4. Mobile

```bash
cd mobile
flutter pub get
dart run build_runner build   # generates Drift's app_database.g.dart
flutter run
```

## Status

This is a scaffold: application structure, tenant-isolation architecture,
auth, and per-module boundaries are wired up per the SRS. Functional
requirements within each module (see `docs/SRS.md` Section 4) are not
yet implemented — each module's `models.py` / `services.py` / `routes.py`
has `TODO` markers pointing at its requirement IDs.

Suggested build order follows the SRS roadmap (§11):

1. **Foundation & Core Lifecycle** — auth/RBAC/RLS (done in scaffold),
   Business Development & CRM, Tender & Bid Management, Estimating,
   Contract Management.
2. **Field Operations MVP** — Planning, Execution, Mobile Field App,
   core QMS/HSE.
3. **Supply Chain & Resources** — Procurement, Inventory, Equipment,
   Fuel, Workforce, Subcontractor Management.
4. **Financial Core & Billing** — Financial Management, Client Billing,
   Project Controls.
5. **Differentiators & Portals** — Survey, Plant & Quarry, Asset
   Management, Executive Dashboard, Client/Vendor Portals.
6. **AI Construction Assistant** — natural-language querying, then
   document extraction, then predictive features.

## Testing

The mandatory tenant-isolation suite (`backend/tests/test_tenant_isolation.py`)
is a required CI gate per SRS §12.2 — as each module's models land, add a
case asserting a user from tenant A can never read or write a tenant B
record, at both the API and RLS layer.
